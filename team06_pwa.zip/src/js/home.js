<<<<<<< HEAD
import { getReports } from '/src/index.js'
 let reports=getReports();
=======
import { getReports } from "../index";
>>>>>>> dba2a161e14cd3c42a10b41a3415adfe6077f876
